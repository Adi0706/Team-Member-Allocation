const content = () => {
  return (
    <main>
      <h1>CONTENT</h1>
    </main>
  )
}

export default content; 